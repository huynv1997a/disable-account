import nextVitals from 'eslint-config-next/core-web-vitals';
import nextTs from 'eslint-config-next/typescript';
import { defineConfig, globalIgnores } from 'eslint/config';
const eslintConfig = defineConfig([
    ...nextVitals,
    ...nextTs,
    globalIgnores(['.next/**', '.netlify/**', 'out/**', 'build/**', 'next-env.d.ts']),
    {
        rules: {}
    }
]);

export default eslintConfig;
